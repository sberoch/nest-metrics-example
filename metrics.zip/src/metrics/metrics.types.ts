export interface Metric {
  request: {
    method: string;
    endpoint: string;
  };
  response?: {
    statusCode: string;
  };
  usage?: {
    startTime: number;
    totalMs: number;
  };
}
