import { Injectable, NestMiddleware } from '@nestjs/common';
import { Request, Response, NextFunction } from 'express';
import { MetricsService } from './metrics.service';

@Injectable()
export class MetricsMiddleware implements NestMiddleware {
  constructor(private readonly metricsService: MetricsService) {}

  use(request: Request, response: Response, next: NextFunction): void {
    const now = Date.now();
    this.metricsService.logRequestStarted(now, request);

    response.on('close', () => {
      this.metricsService.logRequestFinished(now, response);
      this.metricsService.sendDataToSqs(now);
    });

    next();
  }
}
