import { Injectable } from '@nestjs/common';
import { Request, Response } from 'express';
import { Metric } from './metrics.types';

@Injectable()
export class MetricsService {
  private cachedLogs: Record<number, Metric> = {};

  logRequestStarted(timestamp: number, request: Request) {
    console.log('Started...');
    this.cachedLogs[timestamp] = {
      request: {
        method: request.method,
        endpoint: request.originalUrl,
      },
    };
  }

  logRequestFinished(timestamp: number, response: Response) {
    const metric = this.cachedLogs[timestamp];
    Object.assign(metric, {
      response: {
        statusCode: response.statusCode,
      },
      usage: {
        startTime: timestamp,
        totalMs: Date.now() - timestamp,
      },
    });
    console.log(`After... ${Date.now() - timestamp}ms`);
  }

  sendDataToSqs(timestamp: number) {
    console.log(this.cachedLogs[timestamp]);
  }
}
