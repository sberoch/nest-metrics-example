export class CreateCatDto {}
