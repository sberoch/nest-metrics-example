export class Cat {
  id: number;
  name: string;
}
