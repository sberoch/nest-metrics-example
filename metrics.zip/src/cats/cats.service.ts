import { Injectable } from '@nestjs/common';
import { CreateCatDto } from './dto/create-cat.dto';
import { UpdateCatDto } from './dto/update-cat.dto';
import { Cat } from './entities/cat.entity';

@Injectable()
export class CatsService {
  private catsDatabase: Cat[] = [];

  create(createCatDto: CreateCatDto) {
    const cat = new Cat();
    Object.assign(cat, createCatDto);
    this.catsDatabase.push(cat);
    return cat;
  }

  findAll() {
    return this.catsDatabase;
  }

  findOne(id: number) {
    return this.catsDatabase.find((c) => c.id === id);
  }

  update(id: number, updateCatDto: UpdateCatDto) {
    const cat = this.catsDatabase.find((c) => c.id === id);
    Object.assign(
      this.catsDatabase[this.catsDatabase.findIndex((c) => c.id === id)],
      updateCatDto,
    );
    return cat;
  }

  remove(id: number) {
    this.catsDatabase = this.catsDatabase.filter((c) => c.id !== id);
  }
}
